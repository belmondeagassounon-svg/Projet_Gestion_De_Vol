#include "Paiement.h"
#include "Reservation.h"

#include <iostream>
#include <iomanip>
#include <stdexcept>

std::string modeVersTexte(ModePaiement mode)
{
    switch (mode) {
        case ModePaiement::ESPECES:      return "Especes";
        case ModePaiement::CARTE:        return "Carte bancaire";
        case ModePaiement::MOBILE_MONEY: return "Mobile Money";
    }
    return "Inconnu";
}

std::string statutPaiementVersTexte(StatutPaiement statut)
{
    return (statut == StatutPaiement::PAYE) ? "PAYE" : "REMBOURSE";
}

Paiement::Paiement(int id, Reservation* reservation, double montant, ModePaiement mode)
    : id(id), reservation(reservation), montant(montant), mode(mode),
      statut(StatutPaiement::PAYE), montantRembourse(0.0)
{
    if (reservation == nullptr)
        throw std::invalid_argument("Un paiement doit etre associe a une reservation.");
    if (montant < 0)
        throw std::invalid_argument("Le montant d'un paiement ne peut pas etre negatif.");
}

int            Paiement::getId() const               { return id; }
Reservation*   Paiement::getReservation() const      { return reservation; }
double         Paiement::getMontant() const          { return montant; }
ModePaiement   Paiement::getMode() const             { return mode; }
StatutPaiement Paiement::getStatut() const           { return statut; }
double         Paiement::getMontantRembourse() const { return montantRembourse; }

double Paiement::rembourser()
{
    if (statut == StatutPaiement::REMBOURSE)
        throw std::logic_error("Ce paiement a deja ete rembourse.");
    montantRembourse = montant * TAUX_REMBOURSEMENT;
    statut = StatutPaiement::REMBOURSE;
    return montantRembourse;
}

void Paiement::afficher() const
{
    std::cout << "Paiement #" << id
              << " | Montant : " << std::fixed << std::setprecision(0) << montant << " FCFA"
              << " | Mode : " << modeVersTexte(mode)
              << " | Statut : " << statutPaiementVersTexte(statut);
    if (statut == StatutPaiement::REMBOURSE)
        std::cout << " (rembourse : " << montantRembourse << " FCFA)";
    std::cout << std::endl;
}
