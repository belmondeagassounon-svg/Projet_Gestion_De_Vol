#ifndef RESERVATION_H
#define RESERVATION_H

#include <string>

class Passager;
class Vol;
class Paiement;

/*
 * Cycle de vie d'une reservation :
 *   EN_ATTENTE --valider--> VALIDEE --payer--> PAYEE
 *        \                     \                 \
 *         +----------------------+-----annuler----+--> ANNULEE
 */
enum class StatutReservation { EN_ATTENTE, VALIDEE, PAYEE, ANNULEE };

std::string statutReservationVersTexte(StatutReservation statut);

/**
 * Classe Reservation : lie UN passager a UN vol (regle 4).
 * Une place n'est definitivement reservee qu'apres validation (regle 6).
 */
class Reservation {
private:
    int               id;
    Passager*         passager;   // association (1)
    Vol*              vol;        // association (1)
    StatutReservation statut;
    Paiement*         paiement;   // association (0..1)

public:
    Reservation(int id, Passager* passager, Vol* vol);

    int               getId() const;
    Passager*         getPassager() const;
    Vol*              getVol() const;
    StatutReservation getStatut() const;
    Paiement*         getPaiement() const;

    bool occupeUnePlace() const;      // VALIDEE ou PAYEE
    void valider();                   // EN_ATTENTE -> VALIDEE (consomme une place)
    void verifierPayable() const;     // leve std::logic_error si paiement impossible
    void associerPaiement(Paiement* p);   // VALIDEE -> PAYEE
    double annuler();                 // -> ANNULEE ; retourne le montant rembourse (0 si aucun)

    static void afficherEntete();
    void afficherLigne() const;
    void afficherDetails() const;
};

#endif
