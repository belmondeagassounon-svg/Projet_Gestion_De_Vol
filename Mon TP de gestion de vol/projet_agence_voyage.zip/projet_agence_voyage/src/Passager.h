#ifndef PASSAGER_H
#define PASSAGER_H

#include <string>

/**
 * Classe Passager : represente une personne enregistree par l'agence.
 * Un passager doit etre enregistre AVANT de pouvoir reserver un billet.
 */
class Passager {
private:
    int         id;
    std::string nom;
    std::string prenom;
    std::string telephone;
    std::string email;

public:
    // Constructeur : leve std::invalid_argument si nom ou prenom vide
    Passager(int id, const std::string& nom, const std::string& prenom,
             const std::string& telephone, const std::string& email);

    // Accesseurs (encapsulation : les attributs restent prives)
    int         getId() const;
    std::string getNom() const;
    std::string getPrenom() const;
    std::string getTelephone() const;
    std::string getEmail() const;
    std::string getNomComplet() const;

    void afficher() const;
};

#endif
