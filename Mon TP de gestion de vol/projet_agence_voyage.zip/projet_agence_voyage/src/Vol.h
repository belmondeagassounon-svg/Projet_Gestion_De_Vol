#ifndef VOL_H
#define VOL_H

#include <string>

/**
 * Classe Vol : un vol propose par l'agence.
 * Un vol ne peut pas recevoir plus de reservations (validees) que sa capacite.
 */
class Vol {
private:
    std::string numero;          // identifiant unique, ex. "AF123"
    std::string villeDepart;
    std::string villeArrivee;
    std::string dateDepart;      // format JJ/MM/AAAA
    std::string heureDepart;     // format HH:MM
    int         capacite;        // nombre total de places
    int         placesReservees; // places definitivement reservees (reservations validees)
    double      prix;            // prix d'un billet en FCFA

public:
    // Constructeur : leve std::invalid_argument si une donnee est invalide
    Vol(const std::string& numero, const std::string& villeDepart,
        const std::string& villeArrivee, const std::string& dateDepart,
        const std::string& heureDepart, int capacite, double prix);

    // Accesseurs
    std::string getNumero() const;
    std::string getVilleDepart() const;
    std::string getVilleArrivee() const;
    std::string getDateDepart() const;
    std::string getHeureDepart() const;
    int         getCapacite() const;
    int         getPlacesReservees() const;
    double      getPrix() const;

    // Logique metier
    int  getPlacesDisponibles() const;
    bool estComplet() const;
    void reserverPlace();   // leve std::logic_error si le vol est complet
    void libererPlace();    // appelee lors d'une annulation

    // Affichage
    static void afficherEntete();
    void afficherLigne() const;
};

#endif
