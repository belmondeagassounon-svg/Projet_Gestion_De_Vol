#ifndef PAIEMENT_H
#define PAIEMENT_H

#include <string>

class Reservation;   // declaration anticipee (association Paiement -> Reservation)

enum class ModePaiement   { ESPECES, CARTE, MOBILE_MONEY };
enum class StatutPaiement { PAYE, REMBOURSE };

std::string modeVersTexte(ModePaiement mode);
std::string statutPaiementVersTexte(StatutPaiement statut);

/**
 * Classe Paiement : reglement d'une reservation.
 * Si la reservation payee est annulee, le paiement passe au statut REMBOURSE
 * (remboursement de TAUX_REMBOURSEMENT du montant, le reste = frais d'annulation).
 */
class Paiement {
private:
    int            id;
    Reservation*   reservation;      // association : un paiement concerne une reservation
    double         montant;
    ModePaiement   mode;
    StatutPaiement statut;
    double         montantRembourse;

public:
    static constexpr double TAUX_REMBOURSEMENT = 0.80;

    Paiement(int id, Reservation* reservation, double montant, ModePaiement mode);

    int            getId() const;
    Reservation*   getReservation() const;
    double         getMontant() const;
    ModePaiement   getMode() const;
    StatutPaiement getStatut() const;
    double         getMontantRembourse() const;

    double rembourser();   // retourne le montant rembourse ; leve std::logic_error si deja rembourse
    void   afficher() const;
};

#endif
