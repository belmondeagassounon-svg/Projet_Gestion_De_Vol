#ifndef AGENCE_H
#define AGENCE_H

#include <memory>
#include <string>
#include <vector>

#include "Passager.h"
#include "Vol.h"
#include "Reservation.h"
#include "Paiement.h"

/**
 * Classe Agence : point d'entree metier (facade).
 * Elle possede (composition) tous les objets et applique les regles de gestion.
 */
class Agence {
private:
    std::string nom;
    std::vector<std::unique_ptr<Passager>>    passagers;
    std::vector<std::unique_ptr<Vol>>         vols;
    std::vector<std::unique_ptr<Reservation>> reservations;
    std::vector<std::unique_ptr<Paiement>>    paiements;

    int prochainIdPassager;
    int prochainIdReservation;
    int prochainIdPaiement;

    Passager*    trouverPassager(int id) const;
    Vol*         trouverVol(const std::string& numero) const;
    Reservation* trouverReservation(int id) const;

public:
    explicit Agence(const std::string& nom);

    // 1. Gestion des passagers
    Passager& enregistrerPassager(const std::string& nom, const std::string& prenom,
                                  const std::string& telephone, const std::string& email);

    // 2. Gestion des vols
    Vol& ajouterVol(const std::string& numero, const std::string& depart,
                    const std::string& arrivee, const std::string& date,
                    const std::string& heure, int capacite, double prix);
    void afficherVolsDisponibles() const;
    int  rechercherVols(const std::string& depart, const std::string& arrivee) const;

    // 3. Gestion des reservations
    Reservation& effectuerReservation(int idPassager, const std::string& numeroVol);
    void         validerReservation(int idReservation);
    void         afficherReservations() const;
    void         afficherInfosReservation(int idReservation) const;

    // 4. Gestion des paiements et annulations
    Paiement& enregistrerPaiement(int idReservation, ModePaiement mode);
    double    annulerReservation(int idReservation);
};

#endif
