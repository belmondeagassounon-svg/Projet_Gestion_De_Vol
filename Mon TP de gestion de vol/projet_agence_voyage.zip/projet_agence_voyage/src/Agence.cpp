#include "Agence.h"

#include <algorithm>
#include <cctype>
#include <iostream>
#include <stdexcept>

namespace {
    std::string enMinuscules(std::string s)
    {
        std::transform(s.begin(), s.end(), s.begin(),
                       [](unsigned char c) { return std::tolower(c); });
        return s;
    }
}

Agence::Agence(const std::string& nom)
    : nom(nom), prochainIdPassager(1), prochainIdReservation(1), prochainIdPaiement(1) {}

// ---------- Recherches internes ----------
Passager* Agence::trouverPassager(int id) const
{
    for (const auto& p : passagers)
        if (p->getId() == id) return p.get();
    return nullptr;
}

Vol* Agence::trouverVol(const std::string& numero) const
{
    const std::string cle = enMinuscules(numero);
    for (const auto& v : vols)
        if (enMinuscules(v->getNumero()) == cle) return v.get();
    return nullptr;
}

Reservation* Agence::trouverReservation(int id) const
{
    for (const auto& r : reservations)
        if (r->getId() == id) return r.get();
    return nullptr;
}

// ---------- 1. Passagers ----------
Passager& Agence::enregistrerPassager(const std::string& nomP, const std::string& prenom,
                                      const std::string& telephone, const std::string& email)
{
    auto p = std::make_unique<Passager>(prochainIdPassager, nomP, prenom, telephone, email);
    ++prochainIdPassager;                       // incremente seulement si la creation a reussi
    passagers.push_back(std::move(p));
    return *passagers.back();
}

// ---------- 2. Vols ----------
Vol& Agence::ajouterVol(const std::string& numero, const std::string& depart,
                        const std::string& arrivee, const std::string& date,
                        const std::string& heure, int capacite, double prix)
{
    if (trouverVol(numero) != nullptr)
        throw std::invalid_argument("Un vol portant le numero " + numero + " existe deja.");
    vols.push_back(std::make_unique<Vol>(numero, depart, arrivee, date, heure, capacite, prix));
    return *vols.back();
}

void Agence::afficherVolsDisponibles() const
{
    int n = 0;
    for (const auto& v : vols) {
        if (v->estComplet()) continue;
        if (n == 0) Vol::afficherEntete();
        v->afficherLigne();
        ++n;
    }
    if (n == 0) std::cout << "Aucun vol disponible pour le moment." << std::endl;
}

int Agence::rechercherVols(const std::string& depart, const std::string& arrivee) const
{
    const std::string d = enMinuscules(depart), a = enMinuscules(arrivee);
    int n = 0;
    for (const auto& v : vols) {
        bool okDepart  = d.empty() || enMinuscules(v->getVilleDepart()).find(d)  != std::string::npos;
        bool okArrivee = a.empty() || enMinuscules(v->getVilleArrivee()).find(a) != std::string::npos;
        if (okDepart && okArrivee) {
            if (n == 0) Vol::afficherEntete();
            v->afficherLigne();
            ++n;
        }
    }
    if (n == 0) std::cout << "Aucun vol ne correspond a votre recherche." << std::endl;
    return n;
}

// ---------- 3. Reservations ----------
Reservation& Agence::effectuerReservation(int idPassager, const std::string& numeroVol)
{
    // Regle 1 : le passager doit etre enregistre
    Passager* p = trouverPassager(idPassager);
    if (p == nullptr)
        throw std::logic_error("Passager introuvable : il doit etre enregistre avant de reserver.");

    Vol* v = trouverVol(numeroVol);
    if (v == nullptr)
        throw std::logic_error("Vol introuvable : " + numeroVol);

    // Regle 3 : pas deux reservations (non annulees) du meme passager sur le meme vol
    for (const auto& r : reservations)
        if (r->getPassager() == p && r->getVol() == v &&
            r->getStatut() != StatutReservation::ANNULEE)
            throw std::logic_error("Ce passager a deja une reservation sur ce vol.");

    // Regle 2 (controle anticipe) : on refuse si le vol est deja complet
    if (v->estComplet())
        throw std::logic_error("Le vol " + v->getNumero() + " est complet.");

    reservations.push_back(std::make_unique<Reservation>(prochainIdReservation, p, v));
    ++prochainIdReservation;
    return *reservations.back();
}

void Agence::validerReservation(int idReservation)
{
    Reservation* r = trouverReservation(idReservation);
    if (r == nullptr)
        throw std::logic_error("Reservation introuvable.");
    r->valider();   // regles 2 et 6
}

void Agence::afficherReservations() const
{
    if (reservations.empty()) {
        std::cout << "Aucune reservation enregistree." << std::endl;
        return;
    }
    Reservation::afficherEntete();
    for (const auto& r : reservations)
        r->afficherLigne();
}

void Agence::afficherInfosReservation(int idReservation) const
{
    Reservation* r = trouverReservation(idReservation);
    if (r == nullptr)
        throw std::logic_error("Reservation introuvable.");
    r->afficherDetails();
}

// ---------- 4. Paiements et annulations ----------
Paiement& Agence::enregistrerPaiement(int idReservation, ModePaiement mode)
{
    Reservation* r = trouverReservation(idReservation);
    if (r == nullptr)
        throw std::logic_error("Reservation introuvable.");

    r->verifierPayable();   // regle 5 : refuse si annulee (ou non validee / deja payee)

    auto p = std::make_unique<Paiement>(prochainIdPaiement, r, r->getVol()->getPrix(), mode);
    ++prochainIdPaiement;
    paiements.push_back(std::move(p));
    r->associerPaiement(paiements.back().get());
    return *paiements.back();
}

double Agence::annulerReservation(int idReservation)
{
    Reservation* r = trouverReservation(idReservation);
    if (r == nullptr)
        throw std::logic_error("Reservation introuvable.");
    return r->annuler();    // regle 7
}
