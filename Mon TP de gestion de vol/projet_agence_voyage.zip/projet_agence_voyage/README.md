# Agence de voyage - Gestion des vols et des reservations (C++)

Application console (C++17) permettant de gerer les passagers, les vols,
les reservations, les paiements et les annulations d'une agence de voyage.

## Contenu du projet
- `src/`  : code source C++ (Passager, Vol, Reservation, Paiement, Agence, main) + Makefile
- `uml/`  : diagramme de classes UML (`agence_voyage.puml`, PlantUML)
- `Correction_Agence_Voyage.pdf` : dossier de correction detaille

## Fonctionnalites (menu principal)
1. Enregistrer un passager
2. Ajouter un vol
3. Afficher les vols disponibles
4. Rechercher un vol (par ville de depart et/ou d'arrivee)
5. Effectuer une reservation (creation + validation optionnelle)
6. Enregistrer un paiement (Especes, Carte, Mobile Money)
7. Annuler une reservation (remboursement de 80 % si deja payee)
8. Consulter les reservations
9. Afficher les informations d'une reservation
10. Quitter

## Compilation et execution
Avec make :
    cd src
    make
    ./agence          (Windows : agence.exe)

Sans make :
    g++ -std=c++17 -Wall -Wextra -o agence src/*.cpp
    ./agence

## Diagramme UML
Copier `uml/agence_voyage.puml` dans https://www.plantuml.com/plantuml ou utiliser
l'extension PlantUML de VS Code (Alt+D), ou l'import dans Lucid.app.
